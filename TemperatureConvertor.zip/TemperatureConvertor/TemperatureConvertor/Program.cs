﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TemperatureConvertor.net.webservicex.www;
using TemperatureConvertor.net.webservicex.www1;

namespace TemperatureConvertor
{
    class Program
    {
        static void Main(string[] args)
        {
            ConvertTemperature temp = new ConvertTemperature();
            //Console.WriteLine("Please enter the temparature value");
            //Console.WriteLine("Please enter the fromUnit");
            fromUnitOptions();
            Console.WriteLine("Please enter the temparature to be converted");
           Console.WriteLine("Please choose the fromUnit option");
            int choice = Convert.ToInt32(Console.ReadLine());
            fromUnitOptions();

            double temp1 = temp.ConvertTemp(25, TemperatureUnit.degreeCelsius,TemperatureUnit.degreeFahrenheit);
            Console.WriteLine("The temparature is"+temp1);

            CurrencyConvertor convertor = new CurrencyConvertor();

            Console.WriteLine("Please enter the britian currency to be converted to indian rupees");
            double conversionrate = convertor.ConversionRate(Currency.USD,Currency.INR);
            double money = Convert.ToDouble(Console.ReadLine()) * conversionrate;
            Console.WriteLine("The rupess "+money);
            Console.ReadLine();

        }

        static void fromUnitOptions()
        {
            string[] array = {
                "1.Celsius",
                "2.Fahrenheit"
            };
            for (int i = 0; i < array.Length; i++)
            {
                Console.WriteLine(array[i]);
            }


        }
    }
}
